EasyRTC Dev Folder
==================

Any files used strictly by the EasyRTC dev team is kept here. This includes release scripts, dev tests, dictionary words, and dev-only documentation.

Nothing here should be needed by end users.