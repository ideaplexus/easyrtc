The easyrtc.js file is built from the easyrtc_int.js file.
To build it, 

      go to the top level easyrtc directory
      execute "bower install"
      execute "grunt build_api"

You will need to install grunt first.
